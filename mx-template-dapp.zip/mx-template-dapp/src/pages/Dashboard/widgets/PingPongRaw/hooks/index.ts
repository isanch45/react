export * from './useGetTimeToPong';
export * from './useGetPingAmount';
