export * from './pingPong.types';
