export * from './useGetPingAmount';
export * from './useGetTimeToPong';
