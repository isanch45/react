export {
  DECIMALS,
  GAS_PRICE,
  GAS_LIMIT,
  EXTRA_GAS_LIMIT_GUARDED_TX,
  VERSION
} from '@multiversx/sdk-dapp/constants';
