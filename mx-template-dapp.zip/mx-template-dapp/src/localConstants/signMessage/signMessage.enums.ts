export enum SignMessageEnum {
  messageToSign = 'messageToSign'
}
