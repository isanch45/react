import { EnvironmentsEnum } from 'types';

export * from './sharedConfig';

export const contractAddress =
  'erd1qqqqqqqqqqqqqpgqwljf3clfm3np3j9hh9g9y2h8qh0sf8y9hrhq0n3dwt';
export const API_URL = 'https://devnet-template-api.multiversx.com';
export const sampleAuthenticatedDomains = [API_URL];
export const environment = EnvironmentsEnum.devnet;

export const crowdfundingContractAddress =
  'erd1qqqqqqqqqqqqqpgqwljf3clfm3np3j9hh9g9y2h8qh0sf8y9hrhq0n3dwt';
